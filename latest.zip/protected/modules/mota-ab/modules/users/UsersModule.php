<?php
/**
 * Created by Mota-systems company.
 * Author: Pavel Lamzin
 * Date: 17.02.14
 * Time: 2:29
 * All rights are reserved
 */

class UsersModule extends CWebModule{

}