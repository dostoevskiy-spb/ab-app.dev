<?php
/**
 * Created by Mota-systems company.
 * Author: Pavel Lamzin
 * Date: 17.02.14
 * Time: 1:45
 * All rights are reserved
 */

class MotaABModule extends CWebModule
{
    public $defaultController = 'site';

}