<?php
return array(
    'class'            => 'CDbConnection',
    'connectionString' => 'sqlite:' . $_SERVER['DOCUMENT_ROOT'] . '/protected/modules/mota-ab/data/private.sl3'
);