<?php
return array(
    0 => 'mota',
    1 => 'users',
);