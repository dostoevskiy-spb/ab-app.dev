<?php
//echo file_exists(__DIR__ . '/../data/mota.db');
//die();
return array(
    'connectionString' => 'sqlite:' .__DIR__ . '/../data/mota.sl3'
);

