<div class="separator"></div>
<h1>motaCMS v1.0</h1>
<p>Понятная и удобная система для управления сайтом.</p>
<p>
    Email: <a href='mailto:info@mota-systems.com'>info@mota-systems.ru</a><br/>
    Вебсайт: <a href='http://www.mota-systems.com' target='_blank'>www.mota-systems.ru</a>
</p>